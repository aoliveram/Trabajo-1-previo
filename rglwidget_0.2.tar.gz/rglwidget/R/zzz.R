.onAttach <- function(libname, pkgname)
  packageStartupMessage("The functions in the rglwidget package have been moved to rgl.")
